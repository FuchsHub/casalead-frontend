import { readFile } from 'fs/promises';
import path from 'path';

export default async function WidgetPage({ params }: { params: { firmaId: string } }) {
  const htmlPath = path.join(process.cwd(), 'public', 'wertermittlung.html');
  const html = await readFile(htmlPath, 'utf8');

  // Optional: Hier könntest du Farben/CI dynamisch anpassen
  const customizedHtml = html.replace('{{FARBE}}', '#0033cc'); // später dynamisch nach firmaId

  return new Response(customizedHtml, {
    headers: {
      'Content-Type': 'text/html',
      'Cache-Control': 'no-store',
    },
  }) as any; // Type workaround für App Router
}
