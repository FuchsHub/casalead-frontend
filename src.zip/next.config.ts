import type { NextConfig } from "next";

// next.config.js
const nextConfig = {
  experimental: {
    appDir: true
  }
}
module.exports = nextConfig

export default nextConfig;
